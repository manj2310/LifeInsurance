﻿using Microsoft.EntityFrameworkCore;

using System.ComponentModel.DataAnnotations;

namespace LifeInsurance.Models
{
    
    public class PaymentModel
    {
        [Key]
        public int PaymentId { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal PaymentAmount { get; set; }
    }
}
