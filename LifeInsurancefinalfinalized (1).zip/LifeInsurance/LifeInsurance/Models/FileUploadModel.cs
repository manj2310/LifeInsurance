﻿namespace LifeInsurance.Models
{
    public class FileUploadModel
    {
        public IFormFile File { get; set; }
    }
}
