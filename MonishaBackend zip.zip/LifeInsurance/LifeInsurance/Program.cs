using LifeInsurance.Context;
using LifeInsurance.Core;
using LifeInsurance.Core.Interfaces;
using LifeInsurance.Cores;
using LifeInsurance.Cores.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<LifeDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("Myserver")));
builder.Services.AddCors();


//builder.Services.AddAutoMapping(typeof(StartUp));

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = false,
                        ValidateAudience = false,
                        ValidateIssuerSigningKey = true,
                        ValidateLifetime = true,
                        //ValidIssuer = builder.Configuration["Jwt:Issuer"],
                        //ValidAudience = builder.Configuration["Jwt:Audeience"],
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(builder.Configuration["Jwt:Key"]))
                    };
                });
builder.Services.AddScoped<IAdmin, AdminServices>();
builder.Services.AddScoped<IAuth, Auth>();
builder.Services.AddScoped<PolicyCore>();
builder.Services.AddScoped<IUser, User>();
builder.Services.AddScoped<IPlan, PlanServices>();
builder.Services.AddScoped< DocumentServices>();
builder.Services.AddScoped<IPolicy,PolicyCore>();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseCors(c =>
{
    c.AllowAnyHeader().AllowAnyOrigin().AllowAnyMethod();
});
app.UseAuthentication();
app.UseAuthorization();

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});

app.MapControllers();

app.Run();
