﻿using LifeInsurance.Core.Interfaces;
using LifeInsurance.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace LifeInsurance.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
   // [Authorize]
    public class AuthController : Controller
    {
        private readonly IAuth auth;

       private readonly ILogger<AuthController> logger1;
        public  AuthController(IAuth auth)
        {
            this.auth = auth;
            this.logger1 = logger1;
        }
        [HttpPost]
        [Route("Register")]
        [AllowAnonymous]
        public async Task<ResponseModel> RegisterUser([FromBody] UserModel userModel)
        {
            try
            {
                if (userModel != null)
                {
                    var response = await auth.RegisterUser(userModel);
                    return response;
                }
                else
                {
                    ResponseModel response = new ResponseModel();
                    response.Message = "Send proper Request with proper input";
                    response.Status = true;
                    return response;
                }

            }
            catch (System.Exception ex)
            {

                ResponseModel response = new ResponseModel();
                response.ErrorMessage = "Send proper Request with proper input";
                response.Status = false;
                response.ErrorMessage = ex.Message;
                return response;
            }
        }


        [HttpPost]
        [Route("Token")]
        public ResponseModel GenerateToken([FromBody] LoginModel loginModel)
        {
            ResponseModel response = null;
            try
            {

                if (loginModel != null)
                {
                    if (!loginModel.Email.IsNullOrEmpty() && !loginModel.Password.IsNullOrEmpty())
                    {
                        response = auth.GenerateToken(loginModel);

                        return response;

                    }
                    else
                    {
                        response = new ResponseModel();
                        response.Message = "Loggin Succesful";
                        response.Status = true;
                        return response;
                    }
                }
                else
                {
                    response = new ResponseModel();
                    response.Message = "Send proper data in request";
                    response.Status = true;
                    return response;
                }
            }
            catch (System.Exception ex)
            {

                response = new ResponseModel();
                response.Message = "Opps !";
                response.ErrorMessage = ex.Message;
                response.Status = false;
                return response;
            }
        }

        
        
    
    }
}
